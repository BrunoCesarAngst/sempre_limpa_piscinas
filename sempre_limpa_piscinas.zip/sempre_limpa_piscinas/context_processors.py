# from myapp import models

def context_social(request):
    return {'social': 'Exibir este contexto em qualquer lugar!'}